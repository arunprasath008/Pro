import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { NgApexchartsModule } from 'ng-apexcharts';
import {
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexPlotOptions,
  ApexDataLabels,
  ApexTooltip,
  ApexStroke,
  ApexFill
} from 'ng-apexcharts';

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  plotOptions?: ApexPlotOptions;
  dataLabels?: ApexDataLabels;
  tooltip?: ApexTooltip;
  stroke?: ApexStroke;
  fill?: ApexFill;
  colors?: string[];
};



@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [CommonModule, MatCardModule, MatIconModule, NgApexchartsModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {

  chartOptions: Partial<ChartOptions> = {
  series: [
    {
      name: 'Engagement',
      data: [80, 90, 70, 85, 95]
    }
  ],
  chart: {
    type: 'bar',
    height: 200,
    toolbar: { show: false }
  },
  colors: ['#8d6e63'],
  xaxis: {
    categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
    labels: {
      style: {
        colors: '#3e2723',
        fontWeight: 600
      }
    }
  },
  plotOptions: {
    bar: {
      borderRadius: 4,
      columnWidth: '45%'
    }
  },
  dataLabels: {
    enabled: false
  },
  tooltip: {
    theme: 'light'
  }
};


}
