import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { ViewChild, ElementRef } from '@angular/core';
import { ChatbotService } from '../../chatbot.service';


@Component({
  standalone: true,
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule
  ]
})
export class ChatbotComponent {

  constructor(private chatbotService: ChatbotService) {}

  @ViewChild('scrollContainer') scrollContainer!: ElementRef;

  userInput = '';
  isTyping = false;

  messages = [
    {
      sender: 'bot',
      text: 'Hi there! How can I help you today?',
      time: this.getCurrentTime()
    }
  ];

sendMessage() {
  if (!this.userInput.trim()) return;

  const userMessage = {
    sender: 'user',
    text: this.userInput,
    time: this.getCurrentTime()
  };

  this.messages.push(userMessage);
  this.userInput = '';
  this.isTyping = true;
  this.scrollToBottom();

  // Call the dummy chatbot API
  this.chatbotService.getBotResponse(userMessage.text).subscribe(reply => {
    const botMessage = {
      sender: 'bot',
      text: reply.answer,
      time: this.getCurrentTime()
    };

    this.messages.push(botMessage);
    this.isTyping = false;
    this.scrollToBottom();
  });
}


  getCurrentTime(): string {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  scrollToBottom() {
  setTimeout(() => {
    this.scrollContainer.nativeElement.scrollTop =
      this.scrollContainer.nativeElement.scrollHeight;
  });
}

}
