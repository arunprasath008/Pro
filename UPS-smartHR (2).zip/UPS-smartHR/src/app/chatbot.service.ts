// src/app/chatbot.service.ts
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ChatbotService {
  // getBotResponse(userText: string) {
  //   const response = `"${userText}"`;
  //   return of(response).pipe(delay(1200)); // Simulate delay
  // }
  constructor(private http: HttpClient) {}
  getBotResponse(userText: string): Observable<{ answer: string }> {
  const payload = { question: userText };
  return this.http.post<{ answer: string }>(
    'http://localhost:8000/chat',  
    payload
  );
}
}
